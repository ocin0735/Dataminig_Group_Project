import pandas as pd
import plotly.express as px

# Load the dataset
data = pd.read_csv('heart_disease_risk_dataset_earlymed.csv')

# Calculate the number of symptoms for each row
data['Num_Symptoms'] = data[['Chest_Pain', 'Shortness_of_Breath', 'Fatigue', 'Palpitations', 'Dizziness', 'Swelling', 'Pain_Arms_Jaw_Back', 'Cold_Sweats_Nausea']].sum(axis=1)

# Create a 3D scatter plot
fig = px.scatter_3d(data, x='Age', y='Heart_Risk', z='Num_Symptoms', color='Heart_Risk', title='3D Scatter Plot: Age vs. Heart Risk vs. Number of Symptoms')
fig.show()