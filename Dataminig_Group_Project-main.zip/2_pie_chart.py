import pandas as pd
import plotly.express as px

# Load the dataset
data = pd.read_csv('heart_disease_risk_dataset_earlymed.csv')

# Create a petal plot
fig = px.pie(
    data,
    names=['Smoking', 'Alcohol', 'Lack_of_Exercise'],
    title='Petal Plot: Impact of Bad Habits on Heart Disease'
)
fig.show()